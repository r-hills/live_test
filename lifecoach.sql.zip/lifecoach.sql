-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Sep 04, 2015 at 03:52 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lifecoach`
--
CREATE DATABASE IF NOT EXISTS `lifecoach` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `lifecoach`;

-- --------------------------------------------------------

--
-- Table structure for table `daily_completed`
--

CREATE TABLE IF NOT EXISTS `daily_completed` (
  `id` bigint(20) unsigned NOT NULL,
  `day_id` int(11) DEFAULT NULL,
  `complete_today` tinyint(1) DEFAULT NULL,
  `habit_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `daily_completed`
--

INSERT INTO `daily_completed` (`id`, `day_id`, `complete_today`, `habit_id`) VALUES
(1, 0, 1, 5),
(2, 1, 1, 5),
(3, 2, 1, 5),
(4, 3, 1, 5),
(5, 4, 1, 5),
(6, 5, 1, 5),
(7, 6, 1, 5),
(8, 7, 0, 5),
(9, 8, 0, 5),
(10, 9, 0, 5),
(11, 10, 0, 5),
(12, 11, 0, 5),
(13, 0, 1, 6),
(14, 1, 1, 6),
(15, 2, 1, 6),
(16, 3, 0, 6),
(17, 4, 0, 6),
(18, 5, 0, 6),
(19, 6, 0, 6),
(20, 7, 0, 6),
(21, 8, 0, 6),
(22, 9, 0, 6),
(23, 10, 0, 6),
(24, 11, 0, 6),
(25, 12, 0, 6),
(26, 13, 0, 6),
(27, 14, 0, 6),
(28, 15, 0, 6),
(29, 16, 0, 6),
(30, 17, 0, 6),
(31, 18, 0, 6),
(32, 19, 0, 6),
(33, 20, 0, 6),
(34, 21, 0, 6),
(35, 22, 0, 6),
(36, 23, 0, 6),
(37, 24, 0, 6),
(38, 25, 0, 6),
(39, 26, 0, 6),
(40, 27, 0, 6),
(41, 28, 0, 6),
(42, 29, 0, 6),
(43, 30, 0, 6),
(44, 31, 0, 6),
(45, 32, 0, 6),
(46, 33, 0, 6),
(47, 34, 0, 6),
(48, 0, 0, 7),
(49, 1, 0, 7),
(50, 2, 1, 7),
(51, 3, 0, 7),
(52, 4, 0, 7),
(53, 5, 0, 7),
(54, 6, 0, 7),
(55, 7, 0, 7),
(56, 8, 0, 7),
(57, 9, 0, 7),
(58, 10, 0, 7),
(59, 11, 0, 7);

-- --------------------------------------------------------

--
-- Table structure for table `habits`
--

CREATE TABLE IF NOT EXISTS `habits` (
  `id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `motivation` varchar(255) DEFAULT NULL,
  `interval_days` int(11) DEFAULT NULL,
  `completed` tinyint(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `habits`
--

INSERT INTO `habits` (`id`, `name`, `motivation`, `interval_days`, `completed`) VALUES
(6, 'party', 'be cool', 12, 0),
(7, 'dance', 'be cool', 12, 0),
(8, '', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `journals`
--

CREATE TABLE IF NOT EXISTS `journals` (
  `id` bigint(20) unsigned NOT NULL,
  `content` varchar(1000) DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `journals`
--

INSERT INTO `journals` (`id`, `content`, `date`) VALUES
(1, 'blah\r\n fart', '2015-09-03'),
(2, 'blah\r\n fart', '2015-09-03'),
(3, 'today i farted all over everyone.\r\n I was thrown in jail. DAD HATES ME.', '2015-09-03');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `motivation` varchar(255) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `complete` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `motivation`, `due_date`, `priority`, `complete`) VALUES
(1, 'Zda', 'asdasd', '2015-09-17', 1, NULL),
(2, 'Zda', 'asdasd', '2015-09-17', 1, NULL),
(3, 'Zda', 'asdasd', '2015-09-17', 1, NULL),
(4, 'Kevin beautifucation', 'salon', '2015-09-18', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` bigint(20) unsigned NOT NULL,
  `text` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `steps`
--

CREATE TABLE IF NOT EXISTS `steps` (
  `id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `complete` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `steps`
--

INSERT INTO `steps` (`id`, `description`, `project_id`, `position`, `complete`) VALUES
(1, 'touch up face', 4, 7, 1),
(2, 'makeup stuff', 4, 5, 1),
(3, 'add tail', 4, 1, 1),
(4, 'shave hairs', 4, 6, 1),
(5, 'moustache wax', 4, 4, 1),
(6, 'Ear removal', 4, 2, 1),
(7, 'Ear hair removal', 4, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `id_projects` int(11) DEFAULT NULL,
  `id_habits` int(11) DEFAULT NULL,
  `id_journals` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daily_completed`
--
ALTER TABLE `daily_completed`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `habits`
--
ALTER TABLE `habits`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `journals`
--
ALTER TABLE `journals`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `steps`
--
ALTER TABLE `steps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `project_id` (`project_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_projects` (`id_projects`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daily_completed`
--
ALTER TABLE `daily_completed`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=60;
--
-- AUTO_INCREMENT for table `habits`
--
ALTER TABLE `habits`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `journals`
--
ALTER TABLE `journals`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `steps`
--
ALTER TABLE `steps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `steps`
--
ALTER TABLE `steps`
  ADD CONSTRAINT `steps_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_projects`) REFERENCES `projects` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
